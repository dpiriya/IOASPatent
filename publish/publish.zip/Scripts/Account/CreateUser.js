﻿var adl_roles;
$(function () {
    //Declare Variable
    var getcreateuserURL = 'GetCreateUserlist',
     Editcreateuser = 'EditUserlist',
     Deleteuserlist = 'DeletUserlist';
        
    $("#UserList").jsGrid({
        
        autoload: true,
        paging: true,
        pageIndex: 1,
        pageSize: 5,
        editing: true,
        fields: [
            { type: "number", name: "Sno", title: "S.No", editing: false,align:"left",width:"50px"},
            { type: "number", name: "Userid", title: "UserId",visible:false },
            { type: "text", name: "Firstname", title: "Name", editing: false },
            { type: "number", name: "RoleId", title: "Role Id", visible: false },
            { type: "text", name: "RoleName", title: "Role name", editing: false },
            { type: "number", name: "DepartmentId", title: "Department Id", visible: false },
            { type: "text", name: "DepartmentName", title: "Department name", editing: false },
            { type: "text", name: "Usertype", title: "User type", editing: false },
            { Image: "" },
            {
                
                name: "Image",
                
                itemTemplate: function (val, item) {
                    return $("<img>").attr("src", "/Content/UserImage/"+ val).css({ height: 70, width: 70 })
                },
               
            },
        { type: "control" }
           
        ],
        onItemEditing: function (args) {
           
            // cancel editing of the row of item with field 'ID' = 0
            
            if (args.item.Userid > 0) {
                var userid=args.item.Userid;
            }
            $.ajax({
                type: "POST",
                url: Editcreateuser,
                data: { UserId: userid },
                //contentType: "application/json; charset=utf-8",
                //dataType: "json",
               
                success: function (result) {
                  adl_roles = result.SelectedRoles;
                   $("#txtfirstname").val(result.Firstname);
                    $("#txtlastname").val(result.Lastname);
                    $("#ddlgender").val(result.Gender);
                    $("#datepickerid").val(result.DateOfbrith);
                    $("#ddlusertype").val(result.UsertypeId);
                   
                    $("#ddlrolelist").val(result.RoleId);
                    $("#txtupdateusername").val(result.Username);
                    $("#txtuserid").val(result.UserId);
                    $("#ddlinstuitelist").val(result.InstituteId);
                    $('#txtempcode').val(result.EMPCode);
                    $("#ddldepartment").val(result.Department);
                    Filldept();
                    //Fillrole(result.RoleId);
                    
                    $('#gridlist,#addnewpage,#createuserid').hide();
                   $('#createuser,#updateuserid').show();
                },
                error: function (err) {
                    console.log("error1 : " + err);
                }
            });
            
           

        },
        onItemDeleting: function(args) {
            if (args.item.Userid > 0) {
                var userid = args.item.Userid;
            }
            $.ajax({
                type: "POST",
                url: Deleteuserlist,
                data: { UserId: userid },
                //contentType: "application/json; charset=utf-8",
                //dataType: "json",

                success: function (result) {

                    
                    $('#createuserid').hide();
                    $('#updateuserid').hide();
                    $('#createuser').hide();
                    $('#gridlist').show();
                    GetUserlis();
                    $('#myModal3').modal('show');
                       
                },
                error: function (err) {
                    console.log("error1 : " + err);
                }
            });
        }
    });

    //Get User flow details
    $.ajax({
        type: "GET",
        url: getcreateuserURL,
        data: param = "",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (result) {
            dataProcessFlow = result;
            $("#UserList").jsGrid({ data: result });
            
            $('#updateuserid').hide();
            $('#createuser').hide();
            $('#gridlist').show();
        },
        error: function (err) {
            console.log("error : " + err);
        }
        
    });
    function GetUserlis() {

        $.ajax({
            type: "GET",
            url: getcreateuserURL,
            data: param = "",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: false,
            success: function (result) {
                dataProcessFlow = result;
                $("#UserList").jsGrid({ data: result });
                $('#updateuserid').hide();
                $('#createuser').hide();
                $('#gridlist').show();
            },
            error: function (err) {
                console.log("error : " + err);
            }

        });

    }
    
});

